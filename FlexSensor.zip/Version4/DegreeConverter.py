x_points = [0, 500, 650, 850, 990]
y_points = [0, 0.3, 0.5, 0.8, 1.0]
def polynomial(x):
    # Define the polynomial function
    return (-6.40e-13) * x**4 + (5.13e-10) * x**3 + (1.18e-6) * x**2 - (3.66e-5) * x